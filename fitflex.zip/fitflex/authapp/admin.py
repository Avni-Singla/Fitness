from django.contrib import admin
from authapp.models import ContactModel,diettrack
admin.site.register(ContactModel)
admin.site.register(diettrack)
# Register your models here.

